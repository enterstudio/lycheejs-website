
lychee.define('app.net.remote.Chat').includes([
	'lychee.net.remote.Chat'
]).exports(function(lychee, app, global, attachments) {

	/*
	 * IMPLEMENTATION
	 */

	var Class = function(remote) {

		lychee.net.remote.Chat.call(this, 'chat', remote, {
			limit: 1337 // 1337 users allowed to join
		});

	};


	Class.prototype = {

	};


	return Class;

});

